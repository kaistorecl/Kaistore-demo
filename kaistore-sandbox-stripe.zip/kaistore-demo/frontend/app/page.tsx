import Link from 'next/link';

export default function Home() {
  return (
    <main>
      <h1>Kaistore</h1>
      <p>Soluciones domésticas virales para Chile (CLP).</p>
      <p><Link href="/catalog">Ver catálogo</Link></p>
    </main>
  );
}
