interface Product { id:number; title:string; slug:string; description:string; price:number; currency:string; image_url:string; }

function CLP(n:number){ return new Intl.NumberFormat('es-CL', { style:'currency', currency:'CLP'}).format(n); }

async function getProduct(slug: string): Promise<Product|undefined> {
  const res = await fetch(`/api/products`, { cache: 'no-store' });
  const data = await res.json();
  return data.find((p:Product)=>p.slug===slug);
}

export default async function ProductPage({ params }:{ params: { slug:string }}) {
  const p = await getProduct(params.slug);
  if(!p) return <main><p>Producto no encontrado.</p></main>;
  return (
    <main>
      <h1>{p.title}</h1>
      <img src={p.image_url} alt={p.title} style={{maxWidth:540}}/>
      <p>{p.description}</p>
      <p style={{fontSize:24,fontWeight:700}}>{CLP(p.price)}</p>
      <a href="/checkout-demo" style={{padding:12,display:'inline-block',borderRadius:8, background:'#111', color:'#fff'}}>Comprar (demo)</a>
    </main>
  );
}
