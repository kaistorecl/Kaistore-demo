export const metadata = { title: 'Kaistore', description: 'Soluciones domésticas virales (CLP)' };
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body style={{ maxWidth: 1100, margin: '0 auto', fontFamily: 'system-ui', padding: 16 }}>{children}</body>
    </html>
  );
}
