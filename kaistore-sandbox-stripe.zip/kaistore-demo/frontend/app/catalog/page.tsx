import Image from 'next/image';

function CLP(n:number){ return new Intl.NumberFormat('es-CL', { style:'currency', currency:'CLP'}).format(n); }

export default async function Catalog() {
  const res = await fetch(`/api/products`, { cache: 'no-store' });
  const products = await res.json();
  return (
    <main>
      <h1>Catálogo</h1>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))',gap:16}}>
        {products.map((p:any)=>(
          <a key={p.id} href={`/product/${p.slug}`} style={{border:'1px solid #eee',borderRadius:8,padding:12, textDecoration:'none', color:'#111'}}>
            <Image src={p.image_url} alt={p.title} width={400} height={400} style={{width:'100%',height:'auto',borderRadius:8}}/>
            <h3>{p.title}</h3>
            <p style={{fontWeight:600}}>{CLP(p.price)}</p>
          </a>
        ))}
      </div>
    </main>
  );
}
