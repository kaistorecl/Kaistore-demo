export default function CheckoutDemo(){
  return (
    <main>
      <h1>Pago de prueba</h1>
      <p>En esta demo, el botón de comprar abre una sesión de pago Stripe desde la API.</p>
      <p>Usa tarjeta de prueba <b>4242 4242 4242 4242</b>, fecha futura, CVC 123.</p>
      <p>En producción, este enlace debe llamar a <code>/api/orders/checkout</code> con tus productos.</p>
    </main>
  );
}
