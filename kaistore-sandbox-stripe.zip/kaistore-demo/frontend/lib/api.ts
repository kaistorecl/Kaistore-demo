export const API = (typeof window !== 'undefined' ? '' : process.env.NEXT_PUBLIC_API_URL) || '';
