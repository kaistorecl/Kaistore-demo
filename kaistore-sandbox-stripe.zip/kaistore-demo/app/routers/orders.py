import os, stripe
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import Product, Order, OrderItem
from ..config import settings

router = APIRouter(prefix="/api/orders", tags=["orders"])
stripe.api_key = settings.STRIPE_SECRET_KEY

@router.post("/checkout")
def checkout(payload: dict, db: Session = Depends(get_db)):
    items = payload.get("items", [])
    email = payload.get("customer_email")
    if not items or not email:
        raise HTTPException(status_code=400, detail="items and customer_email required")

    order = Order(customer_email=email, status="CREATED", currency=settings.CURRENCY)
    total = 0
    db.add(order); db.flush()
    line_items = []
    for it in items:
        p = db.query(Product).get(it["product_id"])
        if not p:
            raise HTTPException(status_code=404, detail="Product not found")
        qty = int(it.get("qty",1))
        db.add(OrderItem(order_id=order.id, product_id=p.id, qty=qty, unit_price=p.price))
        total += p.price * qty
        line_items.append({
            "price_data": {
                "currency": settings.CURRENCY.lower(),
                "product_data": {"name": p.title},
                "unit_amount": int(p.price),  # CLP entero
            },
            "quantity": qty
        })
    order.total = total; db.commit(); db.refresh(order)

    # Nota: ajusta las URLs cuando lo subas a Render (frontend URL)
    session = stripe.checkout.Session.create(
        mode="payment",
        success_url="https://example.com/success?o="+str(order.id),
        cancel_url="https://example.com/cancel?o="+str(order.id),
        customer_email=email,
        line_items=line_items,
        metadata={"order_id": str(order.id)}
    )
    return {"checkout_url": session.url}
