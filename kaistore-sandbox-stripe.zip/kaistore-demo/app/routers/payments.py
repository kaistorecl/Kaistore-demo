import os, stripe
from fastapi import APIRouter, Request, Header, HTTPException, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import Order
from ..config import settings

router = APIRouter(prefix="/api/payments", tags=["payments"])
stripe.api_key = settings.STRIPE_SECRET_KEY
WH_SECRET = settings.STRIPE_WEBHOOK_SECRET

@router.post("/webhook")
async def stripe_webhook(request: Request, stripe_signature: str = Header(None), db: Session = Depends(get_db)):
    payload = await request.body()
    try:
        event = stripe.Webhook.construct_event(payload, stripe_signature, WH_SECRET)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid signature")

    if event.get("type") == "checkout.session.completed":
        data = event["data"]["object"]
        order_id = int((data.get("metadata") or {}).get("order_id", "0"))
        order = db.query(Order).get(order_id)
        if order and order.status != "PAID":
            order.status = "PAID"
            db.commit()
    return {"received": True}
