from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from ..db import get_db
from ..models import Product
from ..schemas import ProductIn, ProductOut
from ..services.publishing import publish_product

router = APIRouter(prefix="/api/products", tags=["products"])

@router.get("/", response_model=list[ProductOut])
def list_products(db: Session = Depends(get_db)):
    return db.query(Product).filter(Product.active == True).order_by(Product.id.desc()).limit(100).all()

@router.post("/", response_model=ProductOut)
def create_product(payload: ProductIn, db: Session = Depends(get_db)):
    p = publish_product(db, payload)
    return p
